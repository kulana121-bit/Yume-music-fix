/*
 * YumaPlayer (2026) | Modified work by MuwMix
 * ArchiveTune (2026) | Original work by © Rukamori
 * GPL-3.0 License | Contributors: see git history
 */

package moe.rukamori.archivetune.playback

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM
import androidx.media3.common.Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM
import androidx.media3.common.Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
import androidx.media3.common.Player.REPEAT_MODE_OFF
import androidx.media3.common.Player.STATE_ENDED
import androidx.media3.common.Timeline
import androidx.media3.common.Tracks
import androidx.media3.common.C
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.firstOrNull
import moe.rukamori.archivetune.utils.YTPlayerUtils
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.stateIn
import moe.rukamori.archivetune.db.MusicDatabase
import moe.rukamori.archivetune.db.entities.codecLabel
import moe.rukamori.archivetune.db.entities.formattedQuality
import moe.rukamori.archivetune.extensions.currentMetadata
import moe.rukamori.archivetune.extensions.getCurrentQueueIndex
import moe.rukamori.archivetune.extensions.getQueueWindows
import moe.rukamori.archivetune.playback.MusicService.MusicBinder
import moe.rukamori.archivetune.playback.requestTogetherControl
import moe.rukamori.archivetune.playback.queues.Queue
import moe.rukamori.archivetune.utils.reportException
import jakarta.inject.Inject
import kotlin.math.roundToInt


@OptIn(ExperimentalCoroutinesApi::class)
class PlayerConnection(
    context: Context,
    binder: MusicBinder,
    val database: MusicDatabase,
    val scope: CoroutineScope,
) : Player.Listener {
    val service = binder.service
    val player = service.player
    val localPlayer = service.localPlayer

    val playbackState = MutableStateFlow(player.playbackState)
    private val playWhenReady = MutableStateFlow(player.playWhenReady)
    val playbackParameters = MutableStateFlow(player.playbackParameters)
    val isPlaying =
        combine(playbackState, playWhenReady) { playbackState, playWhenReady ->
            playWhenReady && playbackState != STATE_ENDED
        }.stateIn(
            scope,
            SharingStarted.Lazily,
            player.playWhenReady && player.playbackState != STATE_ENDED,
        )
    val mediaMetadata = service.currentMediaMetadata
    val currentSong =
        mediaMetadata.flatMapLatest {
            database.song(it?.id)
        }
    val currentLyrics =
        mediaMetadata.flatMapLatest { mediaMetadata ->
            database.lyrics(mediaMetadata?.id)
        }
    val currentPlaybackSource = service.currentPlaybackSourceFlow
    val currentFormat =
        combine(
            mediaMetadata,
            service.currentPlaybackSourceFlow,
            service.actualPlaybackSources,
        ) { metadata, selectedSource, actualSources ->
            val id = metadata?.id
            if (id == null) {
                null
            } else {
                val effective = actualSources[id] ?: selectedSource
                id to effective
            }
        }.distinctUntilChanged().flatMapLatest { target ->
            if (target == null) kotlinx.coroutines.flow.flowOf(null)
            else database.formatForSource(target.first, target.second)
        }

    val queueTitle = MutableStateFlow<String?>(null)
    val queueWindows = MutableStateFlow<List<Timeline.Window>>(emptyList())
    val currentMediaItemIndex = MutableStateFlow(-1)
    val currentWindowIndex = MutableStateFlow(-1)

    val shuffleModeEnabled = MutableStateFlow(false)
    val repeatMode = MutableStateFlow(REPEAT_MODE_OFF)

    val canSkipPrevious = MutableStateFlow(true)
    val canSkipNext = MutableStateFlow(true)

    val aodModeEnabled = MutableStateFlow(false)
    val audioFormat = MutableStateFlow<String?>(null)

    val error = MutableStateFlow<PlaybackException?>(null)
    val waitingForNetworkConnection = service.waitingForNetworkConnection
    val queueRestoreCompleted = service.queueRestoreCompleted

    init {
        player.addListener(this)

        playbackState.value = player.playbackState
        playWhenReady.value = player.playWhenReady
        playbackParameters.value = player.playbackParameters
        queueTitle.value = service.queueTitle
        queueWindows.value = player.getQueueWindows()
        currentWindowIndex.value = player.getCurrentQueueIndex()
        currentMediaItemIndex.value = player.currentMediaItemIndex
        shuffleModeEnabled.value = player.shuffleModeEnabled
        repeatMode.value = player.repeatMode
        if (player.mediaItemCount > 0 && service.currentMediaMetadata.value == null) {
            service.currentMediaMetadata.value = player.currentMetadata
        }
    }

    private var playRequestGeneration = 0L

    fun beginPlayQueueRequest(): Long {
        return synchronized(this) {
            ++playRequestGeneration
        }
    }

    fun playQueue(queue: Queue) {
        synchronized(this) {
            playRequestGeneration++
            if (moe.rukamori.archivetune.BuildConfig.DEBUG) {
                val mediaId = queue.preloadItem?.id
                    ?: (queue as? moe.rukamori.archivetune.playback.queues.LocalAlbumRadio)?.let { it.albumWithSongs.songs.getOrNull(it.startIndex)?.id }
                    ?: (queue as? moe.rukamori.archivetune.playback.queues.YouTubeQueue)?.endpoint?.videoId
                    ?: PlaybackTiming.lastClickMediaId
                val id = if (mediaId != null && mediaId == PlaybackTiming.lastClickMediaId && PlaybackTiming.lastClickAttemptId > 0L) {
                    PlaybackTiming.lastClickAttemptId
                } else if (mediaId != null) {
                    PlaybackTiming.getAttemptId(mediaId)
                } else {
                    PlaybackTiming.markClick(null)
                }
                PlaybackTiming.log("COMMAND_DISPATCHED", attemptId = id, mediaId = mediaId, extra = "queue=${queue.javaClass.simpleName}")
            }
            service.playQueue(queue)
        }
    }

    fun playQueueIfCurrent(queue: Queue, generation: Long): Boolean {
        synchronized(this) {
            if (generation != playRequestGeneration) return false
            playRequestGeneration++
            if (moe.rukamori.archivetune.BuildConfig.DEBUG) {
                val mediaId = queue.preloadItem?.id
                    ?: (queue as? moe.rukamori.archivetune.playback.queues.LocalAlbumRadio)?.let { it.albumWithSongs.songs.getOrNull(it.startIndex)?.id }
                    ?: (queue as? moe.rukamori.archivetune.playback.queues.YouTubeQueue)?.endpoint?.videoId
                    ?: PlaybackTiming.lastClickMediaId
                val id = if (mediaId != null && mediaId == PlaybackTiming.lastClickMediaId && PlaybackTiming.lastClickAttemptId > 0L) {
                    PlaybackTiming.lastClickAttemptId
                } else if (mediaId != null) {
                    PlaybackTiming.getAttemptId(mediaId)
                } else {
                    PlaybackTiming.markClick(null)
                }
                PlaybackTiming.log("COMMAND_DISPATCHED", attemptId = id, mediaId = mediaId, extra = "queue=${queue.javaClass.simpleName} gated")
            }
            service.playQueue(queue)
            return true
        }
    }

    fun startRadioSeamlessly() {
        synchronized(this) {
            playRequestGeneration++
            service.startRadioSeamlessly()
        }
    }

    fun playNext(item: MediaItem) = playNext(listOf(item))

    fun playNext(items: List<MediaItem>) {
        service.playNext(items)
    }

    fun addToQueue(item: MediaItem) = addToQueue(listOf(item))

    fun addToQueue(items: List<MediaItem>) {
        service.addToQueue(items)
    }

    fun clearQueue() {
        synchronized(this) {
            playRequestGeneration++
            service.clearQueue()
        }
    }

    fun playFromVoiceSearch(query: String) {
        synchronized(this) {
            playRequestGeneration++
            service.playFromVoiceSearch(query)
        }
    }

    fun toggleLike() {
        service.toggleLike()
    }

    fun seekToNext() {
        val state = service.togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (state?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            service.requestTogetherControl(moe.rukamori.archivetune.together.ControlAction.SkipNext)
            return
        }
        player.seekToNext()
        player.prepare()
        player.playWhenReady = true
    }

    fun seekToPrevious() {
        val state = service.togetherSessionState.value as? moe.rukamori.archivetune.together.TogetherSessionState.Joined
        if (state?.role is moe.rukamori.archivetune.together.TogetherRole.Guest) {
            service.requestTogetherControl(moe.rukamori.archivetune.together.ControlAction.SkipPrevious)
            return
        }
        player.seekToPrevious()
        player.prepare()
        player.playWhenReady = true
    }

    override fun onPlaybackStateChanged(state: Int) {
        playbackState.value = state
        error.value = player.playerError
    }

    override fun onPlayWhenReadyChanged(
        newPlayWhenReady: Boolean,
        reason: Int,
    ) {
        playWhenReady.value = newPlayWhenReady
    }

    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
        this.playbackParameters.value = playbackParameters
    }

    override fun onMediaItemTransition(
        mediaItem: MediaItem?,
        reason: Int,
    ) {
        currentMediaItemIndex.value = player.currentMediaItemIndex
        currentWindowIndex.value = player.getCurrentQueueIndex()
        updateCanSkipPreviousAndNext()
    }

    override fun onTimelineChanged(
        timeline: Timeline,
        reason: Int,
    ) {
        queueWindows.value = player.getQueueWindows()
        queueTitle.value = service.queueTitle
        currentMediaItemIndex.value = player.currentMediaItemIndex
        currentWindowIndex.value = player.getCurrentQueueIndex()
        updateCanSkipPreviousAndNext()
    }

    override fun onShuffleModeEnabledChanged(enabled: Boolean) {
        shuffleModeEnabled.value = enabled
        queueWindows.value = player.getQueueWindows()
        currentWindowIndex.value = player.getCurrentQueueIndex()
        updateCanSkipPreviousAndNext()
    }

    override fun onRepeatModeChanged(mode: Int) {
        repeatMode.value = mode
        updateCanSkipPreviousAndNext()
    }

    override fun onPlayerErrorChanged(playbackError: PlaybackException?) {
        if (playbackError != null) {
            reportException(playbackError)
            if (moe.rukamori.archivetune.BuildConfig.DEBUG) {
                var isLogin = false
                var t: Throwable? = playbackError
                while (t != null) {
                    if (t is YTPlayerUtils.LoginRequiredForPlaybackException) {
                        isLogin = true
                        break
                    }
                    t = t.cause
                }
                if (isLogin) {
                    PlaybackTiming.log(
                        "LOGIN_REQUIRED_MEDIA3_HANDLER",
                        mediaId = player.currentMediaItem?.mediaId,
                        extra = "code=${playbackError.errorCode}",
                    )
                }
            }
        }
        error.value = playbackError
    }

    fun dismissPlaybackError() {
        error.value = null
    }

    override fun onTracksChanged(tracks: Tracks) {
        var codecInfo: String? = null
        var foundBitrate = -1
        var foundSampleRate = -1
        var foundMimeType = "UNKNOWN"

        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO && group.isSelected) {
                val format = group.getTrackFormat(0)
                foundMimeType = format.sampleMimeType?.substringAfter("audio/")?.uppercase() ?: "UNKNOWN"

                var bitrate = format.bitrate
                if (bitrate <= 0) bitrate = format.peakBitrate
                if (bitrate <= 0) bitrate = format.averageBitrate

                foundBitrate = bitrate
                foundSampleRate = format.sampleRate
                break
            }
        }

        if (foundMimeType != "UNKNOWN") {
            val isLossless = foundMimeType.contains("FLAC", true) || foundMimeType.contains("ALAC", true)

            if (!isLossless && foundBitrate > 0) {
                val bitrateKbps = if (foundBitrate > 2000) foundBitrate / 1000 else foundBitrate
                audioFormat.value = "$foundMimeType | $bitrateKbps kbps"
            } else {
                scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    val mediaId = mediaMetadata.value?.id ?: return@launch
                    val source = service.actualPlaybackSources.value[mediaId] ?: service.currentPlaybackSource
                    val formatEntity = database.getFormatForSource(mediaId, source)

                    if (mediaMetadata.value?.id != mediaId) return@launch

                    if (isLossless && formatEntity != null) {
                        audioFormat.value = "${formatEntity.codecLabel()} | ${formatEntity.formattedQuality()}"
                    } else if (isLossless && formatEntity == null) {
                        if (foundSampleRate > 0) {
                            val khz = (foundSampleRate / 100.0).roundToInt() / 10.0
                            audioFormat.value = "$foundMimeType | $khz kHz"
                        } else {
                            audioFormat.value = foundMimeType
                        }
                    } else {
                        val finalBitrate = when {
                            foundBitrate > 0 -> foundBitrate
                            formatEntity != null && formatEntity.bitrate > 0 -> formatEntity.bitrate
                            else -> -1
                        }

                        audioFormat.value = if (finalBitrate > 0) {
                            val bitrateKbps = if (finalBitrate > 2000) finalBitrate / 1000 else finalBitrate
                            "$foundMimeType | $bitrateKbps kbps"
                        } else {
                            foundMimeType
                        }
                    }
                }
            }
        }
    }

    private fun updateCanSkipPreviousAndNext() {
        if (!player.currentTimeline.isEmpty) {
            val window =
                player.currentTimeline.getWindow(player.currentMediaItemIndex, Timeline.Window())
            canSkipPrevious.value = player.isCommandAvailable(COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM) ||
                !window.isLive ||
                player.isCommandAvailable(COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
            canSkipNext.value = window.isLive &&
                window.isDynamic ||
                player.isCommandAvailable(COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
        } else {
            canSkipPrevious.value = false
            canSkipNext.value = false
        }
    }

    fun dispose() {
        player.removeListener(this)
    }
}
